/**
 * Check how many vegetables are in the pantry
 */

int main() {

}